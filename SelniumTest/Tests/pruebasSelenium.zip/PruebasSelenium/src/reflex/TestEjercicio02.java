package reflex;

import static org.junit.jupiter.api.Assertions.*;

import java.time.Duration;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

class TestEjercicio02 {
	static WebDriver driver;
	
	public static final String INDEX = "http://localhost:3000/";
	
	@BeforeAll
	static void setURL() {
		driver = new ChromeDriver();
	}
	
	
	@Test
	void test01() {
		driver.get(INDEX);
		String titulo = driver.getTitle();

		assertEquals(titulo, "Formulario de registro - Mi web");
	}
	
	@Test
	void test02() {
		driver.get(INDEX);
		WebElement campo = driver.findElement(By.id("campoNombre"));
		//campo.getAttribute("type");
				
		assertEquals(campo.getTagName(), "input");
	}
	
	@Test
	void test03() {
		driver.get(INDEX);
		WebElement campo = driver.findElement(By.id("campoApellidos"));
				
		assertEquals(campo.getTagName(), "input");
	}
	
	@Test
	void test04() {
		driver.get(INDEX);
		WebElement radio = driver.findElement(By.id("sexRadio"));
		//String radioOptions[] = radio.get
				
		//assertEquals(campo.getTagName(), "input");
	}
	
	@Test
	void test05() {
		driver.get(INDEX);
		WebElement email = driver.findElement(By.id("mailInput"));				
		assertEquals("email", email.getAttribute("type"));
	}
	
	@Test
	void test06() {
		driver.get(INDEX);
		WebElement checkInfo = driver.findElement(By.id("checkInformacion"));	
		assertEquals(checkInfo.getAriaRole(), "checkbox");
	}
	
	@Test
	void test07() {
		driver.get(INDEX);
		WebElement checkInfo = driver.findElement(By.id("checkInformacion"));	
		assertEquals(checkInfo.getAttribute("aria-checked"), "true");
	}
	
	@Test
	void test08() {
		driver.get(INDEX);
		WebElement textInfo = driver.findElement(By.id("textInformacion"));	

		assertEquals(textInfo.getText(), "Deseo recibir información sobre novedades y ofertas");
	}
	
	@Test
	void test09() {
		driver.get(INDEX);
		WebElement checkCond = driver.findElement(By.id("checkCondiciones"));	
		assertEquals(checkCond.getAriaRole(), "checkbox");
	}
	
	@Test
	void test10() {
		driver.get(INDEX);
		WebElement checkCond = driver.findElement(By.id("checkCondiciones"));	
		assertEquals(checkCond.getAttribute("aria-checked"), "false");
	}
	
	@Test
	void test11() {
		driver.get(INDEX);
		WebElement textCond = driver.findElement(By.id("textCondiciones"));	

		assertEquals(textCond.getText(), "Declaro haber leido y aceptar las condiciones generales del programa y la normativa sobre protección de datos");
	}
	
	@Test
	void test12() {
		driver.get(INDEX);
		WebElement campo = driver.findElement(By.id("campoNombre"));
				
		assertEquals(campo.getAttribute("maxlength"), "50");
	}
	
	@Test
	void test13() {
		driver.get(INDEX);
		WebElement campo = driver.findElement(By.id("campoApellidos"));
				
		assertEquals(campo.getAttribute("maxlength"), "50");
	}

}
